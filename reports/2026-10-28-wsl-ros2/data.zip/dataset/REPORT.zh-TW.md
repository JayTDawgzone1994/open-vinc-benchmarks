# Open-VINC／ROS 2：WSL 同機實測報告

資料集：`20261028-224514-735300`。狀態：完整執行結束。

這是本機 WSL2 Ubuntu 24.04 的原生 C++ API 比較，不是原生 Linux 部署認證、
Apex.AI performance_test 成績、所有 ROS 後端排名或硬即時保證。

## 測試邊界

- 同一台 Ryzen 7 5700X3D、16 個邏輯 CPU；Windows 11 上的 WSL2 Ubuntu 24.04.5。
- Open-VINC 固定版本 `a3a0843c5dc89f8b052c5f25afa66e1f171db99e`，未修改框架。
- ROS 2 Jazzy、rclcpp 28.1.22、rmw_fastrtps_cpp 8.4.4、Fast DDS 2.14.7、Fast CDR 2.2.8。
- 雙方 GCC/libstdc++ 13.3、Release；每組各一個獨立 Publisher／Subscriber 程序。Vinc 另有中央監督程序。
- 延遲從 publish／push／commit API 入口到取得獨立本機副本的 callback 入口，使用同機 CLOCK_MONOTONIC。
- 普通 push／ROS publish 重用預先初始化的本機 byte vector；序號逐筆更新。接收檢查長度、序號與頭尾標記，不是完整內容雜湊。
- ROS 使用持有本機訊息的 SharedPtr callback，RMW loans 與 intra-process routing 關閉；不把共享記憶體借用視圖當成本機副本。
- 早期 UniquePtr 診斷會在 rclcpp 派送時額外深拷貝，已另存且排除在本次主資料集之外；詳見 ROS 工作負載 README 與固定版本的 rclcpp dispatch 實作。
- 不使用 busy spin、全域計時器調整、CPU 綁核或優先級調整；未量測功耗。桌面背景負載未隔離。
- 每輪 1,000 筆正式資料，3 輪；另有至少 64 筆暖身。P99 用 nearest rank，不從平均值推估。

## 容量與共同速率

先以校準試跑選定速率，再凍結正式測試設定。主矩陣從 100 Hz 逐級下降；校準須完整收送、
Vinc 無碰撞／覆寫／漏收且實際頻率落在要求的 ±5%。另以校準 P90 ≤ 四個週期、前後半段中位數成長 ≤ 一個週期選擇餘裕；這不是正式測試的延遲 SLA。ROS 預設設定另作對照，不決定調校組的共同速率。
所有 100 Hz 失敗試跑仍列在下方。32 格 RingBuffer，128 MiB 使用 30 格；實際 Bus 配置不得超過 4 GiB。
DDS 另有控制區、序列化緩衝與備用格，不能把相同深度說成相同總記憶體。

| Payload | 格數 | 共同 Hz | ROS 調校路徑 |
|---|---:|---:|---|
| 1 KiB | 32 | 100 | datasharing |
| 1 MiB | 32 | 100 | datasharing |
| 8 MiB | 32 | 100 | datasharing |
| 16 MiB | 32 | 100 | datasharing |
| 32 MiB | 32 | 25 | datasharing |
| 64 MiB | 32 | 10 | datasharing |
| 128 MiB | 30 | 5 | datasharing |

## 正式結果

下表 P50／P90／P99 各自取 3 輪統計值的中位數，**不是合併樣本後的百分位數**。
P99 範圍列出各輪差異；有任一失敗，整組不標為全部通過，也不隱藏該輪。
ROS default 為 RELIABLE、預設傳輸及 Data Sharing OFF；調校組為 BEST_EFFORT、
明確 ON 的 Data Sharing（有界訊息），或明確 SHM fallback。Vinc 的覆寫與讀取保護契約不同，不能據此宣稱可靠度等同。

| Payload | 路徑 | 合格輪數 | 實際 Hz 範圍 | P50 / P90 / P99 中位數 ms | P99 範圍 ms | 全部樣本最大 ms |
|---|---|---:|---:|---:|---:|---:|
| 1 KiB | datasharing | 3/3 | 99.998–100.000 | 0.121 / 0.155 / 0.233 | 0.198–0.241 | 0.353 |
| 1 KiB | default | 3/3 | 99.999–99.999 | 0.158 / 0.216 / 0.322 | 0.309–0.440 | 1.071 |
| 1 KiB | vinc | 3/3 | 99.999–100.000 | 0.063 / 0.082 / 0.105 | 0.099–0.116 | 0.230 |
| 1 MiB | datasharing | 3/3 | 99.999–99.999 | 0.259 / 0.354 / 0.507 | 0.495–0.543 | 0.922 |
| 1 MiB | default | 3/3 | 99.999–100.000 | 0.553 / 0.720 / 1.126 | 1.105–1.130 | 11.564 |
| 1 MiB | vinc | 3/3 | 99.997–99.999 | 0.299 / 0.387 / 0.569 | 0.484–0.636 | 1.005 |
| 8 MiB | datasharing | 3/3 | 99.999–100.000 | 1.916 / 2.513 / 3.519 | 3.264–3.679 | 6.105 |
| 8 MiB | default | 3/3 | 99.999–99.999 | 4.204 / 6.031 / 15.994 | 14.120–16.600 | 25.553 |
| 8 MiB | vinc | 3/3 | 99.998–99.999 | 2.226 / 2.766 / 4.074 | 3.462–4.591 | 5.983 |
| 16 MiB | datasharing | 3/3 | 99.998–99.999 | 4.350 / 5.876 / 7.621 | 6.935–8.023 | 9.587 |
| 16 MiB | default | 0/3 | 86.418–95.964 | 17.946 / 34.648 / 55.473 | 46.504–57.238 | 75.445 |
| 16 MiB | vinc | 3/3 | 99.999–100.000 | 4.894 / 6.225 / 7.746 | 7.098–7.961 | 12.717 |
| 32 MiB | datasharing | 3/3 | 25.000–25.000 | 27.022 / 29.541 / 32.624 | 30.490–49.393 | 61.006 |
| 32 MiB | default | 0/3 | 23.854–24.703 | 372.799 / 552.598 / 697.083 | 624.079–881.056 | 4450.802 |
| 32 MiB | vinc | 3/3 | 25.000–25.000 | 28.056 / 30.782 / 36.449 | 35.434–130.122 | 153.709 |
| 64 MiB | datasharing | 3/3 | 10.000–10.000 | 58.300 / 63.313 / 73.908 | 68.486–465.514 | 636.640 |
| 64 MiB | default | 2/3 | 9.950–10.000 | 189.275 / 451.289 / 1000.096 | 297.296–2280.866 | 2468.312 |
| 64 MiB | vinc | 3/3 | 10.000–10.000 | 60.325 / 65.312 / 79.531 | 76.883–81.317 | 133.619 |
| 128 MiB | datasharing | 3/3 | 5.000–5.000 | 107.221 / 127.648 / 147.014 | 139.923–153.464 | 268.561 |
| 128 MiB | default | 0/3 | 5.000–5.000 | 389.704 / 1429.354 / 2860.549 | 2593.246–3854.930 | 4316.536 |
| 128 MiB | vinc | 3/3 | 5.000–5.000 | 126.922 / 141.202 / 178.721 | 175.338–188.565 | 315.154 |

## CPU 與記憶體

CPU 100% 表示一個邏輯核心。Publisher 用排除暖身與寫檔的正式發布區間；
Subscriber／中央用含啟動、暖身與收尾等待的 lifecycle-to-report 區間，不能把不同區間的百分比相加。
表中為各輪中位數；RSS 為各程序生命週期 high-water，會重複計入共享頁，不能加總為實體記憶體。

| Payload | 路徑 | Pub 正式 CPU % | Sub lifecycle CPU % | 中央 lifecycle CPU % | Pub / Sub / 中央最大 RSS MiB |
|---|---|---:|---:|---:|---:|
| 1 KiB | datasharing | 0.597 | 1.677 | — | 96.5 / 96.5 / — |
| 1 KiB | default | 1.236 | 1.252 | — | 27.7 / 27.5 / — |
| 1 KiB | vinc | 0.617 | 0.449 | 1.384 | 5.4 / 5.1 / 19.5 |
| 1 MiB | datasharing | 1.529 | 2.366 | — | 130.5 / 130.4 / — |
| 1 MiB | default | 5.089 | 3.720 | — | 30.6 / 31.0 / — |
| 1 MiB | vinc | 1.949 | 1.461 | 1.413 | 38.3 / 38.3 / 19.4 |
| 8 MiB | datasharing | 9.016 | 11.691 | — | 368.6 / 368.6 / — |
| 8 MiB | default | 33.532 | 22.726 | — | 195.6 / 188.0 / — |
| 8 MiB | vinc | 12.800 | 9.501 | 1.452 | 269.4 / 269.3 / 19.5 |
| 16 MiB | datasharing | 20.413 | 24.645 | — | 640.4 / 640.5 / — |
| 16 MiB | default | 74.932 | 35.989 | — | 571.7 / 572.3 / — |
| 16 MiB | vinc | 26.023 | 20.896 | 1.616 | 533.2 / 533.2 / 19.4 |
| 32 MiB | datasharing | 10.080 | 61.490 | — | 1184.4 / 1184.5 / — |
| 32 MiB | default | 72.545 | 72.526 | — | 1115.6 / 1116.4 / — |
| 32 MiB | vinc | 14.239 | 58.572 | 1.457 | 1061.3 / 1061.3 / 19.5 |
| 64 MiB | datasharing | 8.793 | 54.431 | — | 2272.2 / 2272.6 / — |
| 64 MiB | default | 44.252 | 68.936 | — | 2203.3 / 2204.3 / — |
| 64 MiB | vinc | 11.680 | 52.900 | 1.576 | 2117.2 / 2117.0 / 19.5 |
| 128 MiB | datasharing | 6.160 | 53.752 | — | 4192.3 / 4192.5 / — |
| 128 MiB | default | 48.987 | 67.055 | — | 4123.5 / 4124.2 / — |
| 128 MiB | vinc | 8.743 | 60.363 | 1.558 | 3973.3 / 3973.1 / 19.5 |

## Vinc loan 補充

每個大小另做一輪，與 ROS 普通 publish 不作同工作量倍率比較。commit 延遲不含 get_next／resize／初始化；
full_path 額外包含這些準備成本。兩欄各自計算百分位數，不可相加。

| Payload | 合格 | 實際 Hz | commit P99 ms | full_path P99 ms |
|---|---|---:|---:|---:|
| 1 KiB | True | 100.000 | 0.109 | 0.132 |
| 1 MiB | True | 100.000 | 0.290 | 0.682 |
| 8 MiB | True | 99.993 | 2.001 | 4.320 |
| 16 MiB | True | 99.994 | 3.749 | 7.524 |
| 32 MiB | True | 24.604 | 34.352 | 72.939 |
| 64 MiB | True | 9.980 | 68.881 | 149.898 |
| 128 MiB | True | 4.980 | 158.708 | 303.336 |

## 全部嘗試與失敗

下表涵蓋正式、校準及設定預檢。即使有部分好看的延遲數字，漏收、碰撞或低於要求速率的結果仍不合格。
ROS 的內部碰撞／覆寫計數為 null（未提供），並非測得零；端到端漏收由精確 ID 清單判定。

| 階段 | Payload | 路徑 | 要求 Hz | 實際 Hz | 合格 | 問題／計數 | 原始資料 |
|---|---|---|---:|---:|---|---|---|
| profile r0 | 1 KiB | datasharing push | 10 | 9.999 | True | {} | [資料](profile-1024-10hz-r0-datasharing-push/controller.json) |
| profile r0 | 1 KiB | shm push | 10 | 9.999 | True | {} | [資料](profile-1024-10hz-r0-shm-push/controller.json) |
| pilot r0 | 1 KiB | vinc push | 100 | 99.993 | True | {} | [資料](pilot-1024-100hz-r0-vinc-push/controller.json) |
| pilot r0 | 1 KiB | datasharing push | 100 | 99.994 | True | {} | [資料](pilot-1024-100hz-r0-datasharing-push/controller.json) |
| formal r1 | 1 KiB | vinc push | 100 | 99.999 | True | {} | [資料](formal-1024-100hz-r1-vinc-push/controller.json) |
| formal r1 | 1 KiB | default push | 100 | 99.999 | True | {} | [資料](formal-1024-100hz-r1-default-push/controller.json) |
| formal r1 | 1 KiB | datasharing push | 100 | 100.000 | True | {} | [資料](formal-1024-100hz-r1-datasharing-push/controller.json) |
| formal r2 | 1 KiB | datasharing push | 100 | 99.998 | True | {} | [資料](formal-1024-100hz-r2-datasharing-push/controller.json) |
| formal r2 | 1 KiB | default push | 100 | 99.999 | True | {} | [資料](formal-1024-100hz-r2-default-push/controller.json) |
| formal r2 | 1 KiB | vinc push | 100 | 100.000 | True | {} | [資料](formal-1024-100hz-r2-vinc-push/controller.json) |
| formal r3 | 1 KiB | vinc push | 100 | 99.999 | True | {} | [資料](formal-1024-100hz-r3-vinc-push/controller.json) |
| formal r3 | 1 KiB | default push | 100 | 99.999 | True | {} | [資料](formal-1024-100hz-r3-default-push/controller.json) |
| formal r3 | 1 KiB | datasharing push | 100 | 99.999 | True | {} | [資料](formal-1024-100hz-r3-datasharing-push/controller.json) |
| loan r1 | 1 KiB | vinc loan | 100 | 100.000 | True | {} | [資料](loan-1024-100hz-r1-vinc-loan/controller.json) |
| profile r0 | 1 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](profile-1048576-10hz-r0-datasharing-push/controller.json) |
| profile r0 | 1 MiB | shm push | 10 | 10.000 | True | {} | [資料](profile-1048576-10hz-r0-shm-push/controller.json) |
| pilot r0 | 1 MiB | vinc push | 100 | 99.993 | True | {} | [資料](pilot-1048576-100hz-r0-vinc-push/controller.json) |
| pilot r0 | 1 MiB | datasharing push | 100 | 99.995 | True | {} | [資料](pilot-1048576-100hz-r0-datasharing-push/controller.json) |
| formal r1 | 1 MiB | vinc push | 100 | 99.997 | True | {} | [資料](formal-1048576-100hz-r1-vinc-push/controller.json) |
| formal r1 | 1 MiB | default push | 100 | 99.999 | True | {} | [資料](formal-1048576-100hz-r1-default-push/controller.json) |
| formal r1 | 1 MiB | datasharing push | 100 | 99.999 | True | {} | [資料](formal-1048576-100hz-r1-datasharing-push/controller.json) |
| formal r2 | 1 MiB | datasharing push | 100 | 99.999 | True | {} | [資料](formal-1048576-100hz-r2-datasharing-push/controller.json) |
| formal r2 | 1 MiB | default push | 100 | 99.999 | True | {} | [資料](formal-1048576-100hz-r2-default-push/controller.json) |
| formal r2 | 1 MiB | vinc push | 100 | 99.999 | True | {} | [資料](formal-1048576-100hz-r2-vinc-push/controller.json) |
| formal r3 | 1 MiB | vinc push | 100 | 99.999 | True | {} | [資料](formal-1048576-100hz-r3-vinc-push/controller.json) |
| formal r3 | 1 MiB | default push | 100 | 100.000 | True | {} | [資料](formal-1048576-100hz-r3-default-push/controller.json) |
| formal r3 | 1 MiB | datasharing push | 100 | 99.999 | True | {} | [資料](formal-1048576-100hz-r3-datasharing-push/controller.json) |
| loan r1 | 1 MiB | vinc loan | 100 | 100.000 | True | {} | [資料](loan-1048576-100hz-r1-vinc-loan/controller.json) |
| profile r0 | 8 MiB | datasharing push | 10 | 9.997 | True | {} | [資料](profile-8388608-10hz-r0-datasharing-push/controller.json) |
| profile r0 | 8 MiB | shm push | 10 | 10.000 | True | {} | [資料](profile-8388608-10hz-r0-shm-push/controller.json) |
| pilot r0 | 8 MiB | vinc push | 100 | 99.994 | True | {} | [資料](pilot-8388608-100hz-r0-vinc-push/controller.json) |
| pilot r0 | 8 MiB | datasharing push | 100 | 99.995 | True | {} | [資料](pilot-8388608-100hz-r0-datasharing-push/controller.json) |
| formal r1 | 8 MiB | vinc push | 100 | 99.999 | True | {} | [資料](formal-8388608-100hz-r1-vinc-push/controller.json) |
| formal r1 | 8 MiB | default push | 100 | 99.999 | True | {} | [資料](formal-8388608-100hz-r1-default-push/controller.json) |
| formal r1 | 8 MiB | datasharing push | 100 | 100.000 | True | {} | [資料](formal-8388608-100hz-r1-datasharing-push/controller.json) |
| formal r2 | 8 MiB | datasharing push | 100 | 99.999 | True | {} | [資料](formal-8388608-100hz-r2-datasharing-push/controller.json) |
| formal r2 | 8 MiB | default push | 100 | 99.999 | True | {} | [資料](formal-8388608-100hz-r2-default-push/controller.json) |
| formal r2 | 8 MiB | vinc push | 100 | 99.999 | True | {} | [資料](formal-8388608-100hz-r2-vinc-push/controller.json) |
| formal r3 | 8 MiB | vinc push | 100 | 99.998 | True | {} | [資料](formal-8388608-100hz-r3-vinc-push/controller.json) |
| formal r3 | 8 MiB | default push | 100 | 99.999 | True | {} | [資料](formal-8388608-100hz-r3-default-push/controller.json) |
| formal r3 | 8 MiB | datasharing push | 100 | 99.999 | True | {} | [資料](formal-8388608-100hz-r3-datasharing-push/controller.json) |
| loan r1 | 8 MiB | vinc loan | 100 | 99.993 | True | {} | [資料](loan-8388608-100hz-r1-vinc-loan/controller.json) |
| profile r0 | 16 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](profile-16777216-10hz-r0-datasharing-push/controller.json) |
| profile r0 | 16 MiB | shm push | 10 | 10.000 | True | {} | [資料](profile-16777216-10hz-r0-shm-push/controller.json) |
| pilot r0 | 16 MiB | vinc push | 100 | 99.996 | True | {} | [資料](pilot-16777216-100hz-r0-vinc-push/controller.json) |
| pilot r0 | 16 MiB | datasharing push | 100 | 99.997 | True | {} | [資料](pilot-16777216-100hz-r0-datasharing-push/controller.json) |
| formal r1 | 16 MiB | vinc push | 100 | 99.999 | True | {} | [資料](formal-16777216-100hz-r1-vinc-push/controller.json) |
| formal r1 | 16 MiB | default push | 100 | 86.418 | False | {'missing_receive': 2, 'analyzer': 'unqualified'} | [資料](formal-16777216-100hz-r1-default-push/controller.json) |
| formal r1 | 16 MiB | datasharing push | 100 | 99.999 | True | {} | [資料](formal-16777216-100hz-r1-datasharing-push/controller.json) |
| formal r2 | 16 MiB | datasharing push | 100 | 99.999 | True | {} | [資料](formal-16777216-100hz-r2-datasharing-push/controller.json) |
| formal r2 | 16 MiB | default push | 100 | 95.964 | False | {'missing_receive': 1, 'analyzer': 'unqualified'} | [資料](formal-16777216-100hz-r2-default-push/controller.json) |
| formal r2 | 16 MiB | vinc push | 100 | 100.000 | True | {} | [資料](formal-16777216-100hz-r2-vinc-push/controller.json) |
| formal r3 | 16 MiB | vinc push | 100 | 99.999 | True | {} | [資料](formal-16777216-100hz-r3-vinc-push/controller.json) |
| formal r3 | 16 MiB | default push | 100 | 92.073 | False | {'rate': 'outside ±5%'} | [資料](formal-16777216-100hz-r3-default-push/controller.json) |
| formal r3 | 16 MiB | datasharing push | 100 | 99.998 | True | {} | [資料](formal-16777216-100hz-r3-datasharing-push/controller.json) |
| loan r1 | 16 MiB | vinc loan | 100 | 99.994 | True | {} | [資料](loan-16777216-100hz-r1-vinc-loan/controller.json) |
| profile r0 | 32 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](profile-33554432-10hz-r0-datasharing-push/controller.json) |
| profile r0 | 32 MiB | shm push | 10 | 9.998 | True | {} | [資料](profile-33554432-10hz-r0-shm-push/controller.json) |
| pilot r0 | 32 MiB | vinc push | 100 | 99.994 | False | {'missing_receive': 80, 'lost_messages': 80, 'overwrite_events': 34, 'analyzer': 'unqualified'} | [資料](pilot-33554432-100hz-r0-vinc-push/controller.json) |
| pilot r0 | 32 MiB | datasharing push | 100 | 99.994 | False | {'missing_receive': 56, 'analyzer': 'unqualified'} | [資料](pilot-33554432-100hz-r0-datasharing-push/controller.json) |
| pilot r0 | 32 MiB | vinc push | 50 | 49.996 | False | {'missing_receive': 23, 'lost_messages': 23, 'overwrite_events': 20, 'analyzer': 'unqualified'} | [資料](pilot-33554432-50hz-r0-vinc-push/controller.json) |
| pilot r0 | 32 MiB | datasharing push | 50 | 49.999 | True | {} | [資料](pilot-33554432-50hz-r0-datasharing-push/controller.json) |
| pilot r0 | 32 MiB | vinc push | 25 | 25.000 | True | {} | [資料](pilot-33554432-25hz-r0-vinc-push/controller.json) |
| pilot r0 | 32 MiB | datasharing push | 25 | 24.998 | True | {} | [資料](pilot-33554432-25hz-r0-datasharing-push/controller.json) |
| formal r1 | 32 MiB | vinc push | 25 | 25.000 | True | {} | [資料](formal-33554432-25hz-r1-vinc-push/controller.json) |
| formal r1 | 32 MiB | default push | 25 | 24.703 | False | {'missing_receive': 3, 'analyzer': 'unqualified'} | [資料](formal-33554432-25hz-r1-default-push/controller.json) |
| formal r1 | 32 MiB | datasharing push | 25 | 25.000 | True | {} | [資料](formal-33554432-25hz-r1-datasharing-push/controller.json) |
| formal r2 | 32 MiB | datasharing push | 25 | 25.000 | True | {} | [資料](formal-33554432-25hz-r2-datasharing-push/controller.json) |
| formal r2 | 32 MiB | default push | 25 | 24.654 | False | {'missing_receive': 2, 'analyzer': 'unqualified'} | [資料](formal-33554432-25hz-r2-default-push/controller.json) |
| formal r2 | 32 MiB | vinc push | 25 | 25.000 | True | {} | [資料](formal-33554432-25hz-r2-vinc-push/controller.json) |
| formal r3 | 32 MiB | vinc push | 25 | 25.000 | True | {} | [資料](formal-33554432-25hz-r3-vinc-push/controller.json) |
| formal r3 | 32 MiB | default push | 25 | 23.854 | False | {'missing_receive': 7, 'analyzer': 'unqualified'} | [資料](formal-33554432-25hz-r3-default-push/controller.json) |
| formal r3 | 32 MiB | datasharing push | 25 | 25.000 | True | {} | [資料](formal-33554432-25hz-r3-datasharing-push/controller.json) |
| loan r1 | 32 MiB | vinc loan | 25 | 24.604 | True | {} | [資料](loan-33554432-25hz-r1-vinc-loan/controller.json) |
| profile r0 | 64 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](profile-67108864-10hz-r0-datasharing-push/controller.json) |
| profile r0 | 64 MiB | shm push | 10 | 10.000 | True | {} | [資料](profile-67108864-10hz-r0-shm-push/controller.json) |
| pilot r0 | 64 MiB | vinc push | 100 | 49.606 | False | {'missing_receive': 93, 'collisions': 1, 'lost_messages': 93, 'overwrite_events': 34, 'analyzer': 'unqualified'} | [資料](pilot-67108864-100hz-r0-vinc-push/controller.json) |
| pilot r0 | 64 MiB | datasharing push | 100 | 56.193 | False | {'missing_receive': 77, 'analyzer': 'unqualified'} | [資料](pilot-67108864-100hz-r0-datasharing-push/controller.json) |
| pilot r0 | 64 MiB | vinc push | 50 | 49.999 | False | {'missing_receive': 92, 'lost_messages': 92, 'overwrite_events': 39, 'analyzer': 'unqualified'} | [資料](pilot-67108864-50hz-r0-vinc-push/controller.json) |
| pilot r0 | 64 MiB | datasharing push | 50 | 49.223 | False | {'missing_receive': 62, 'analyzer': 'unqualified'} | [資料](pilot-67108864-50hz-r0-datasharing-push/controller.json) |
| pilot r0 | 64 MiB | vinc push | 25 | 24.998 | False | {'missing_receive': 36, 'collisions': 1, 'lost_messages': 36, 'overwrite_events': 30, 'analyzer': 'unqualified'} | [資料](pilot-67108864-25hz-r0-vinc-push/controller.json) |
| pilot r0 | 64 MiB | datasharing push | 25 | 25.000 | False | {'missing_receive': 3, 'analyzer': 'unqualified'} | [資料](pilot-67108864-25hz-r0-datasharing-push/controller.json) |
| pilot r0 | 64 MiB | vinc push | 10 | 10.000 | True | {} | [資料](pilot-67108864-10hz-r0-vinc-push/controller.json) |
| pilot r0 | 64 MiB | datasharing push | 10 | 9.999 | True | {} | [資料](pilot-67108864-10hz-r0-datasharing-push/controller.json) |
| formal r1 | 64 MiB | vinc push | 10 | 10.000 | True | {} | [資料](formal-67108864-10hz-r1-vinc-push/controller.json) |
| formal r1 | 64 MiB | default push | 10 | 9.950 | True | {} | [資料](formal-67108864-10hz-r1-default-push/controller.json) |
| formal r1 | 64 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](formal-67108864-10hz-r1-datasharing-push/controller.json) |
| formal r2 | 64 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](formal-67108864-10hz-r2-datasharing-push/controller.json) |
| formal r2 | 64 MiB | default push | 10 | 9.960 | False | {'missing_receive': 5, 'analyzer': 'unqualified'} | [資料](formal-67108864-10hz-r2-default-push/controller.json) |
| formal r2 | 64 MiB | vinc push | 10 | 10.000 | True | {} | [資料](formal-67108864-10hz-r2-vinc-push/controller.json) |
| formal r3 | 64 MiB | vinc push | 10 | 10.000 | True | {} | [資料](formal-67108864-10hz-r3-vinc-push/controller.json) |
| formal r3 | 64 MiB | default push | 10 | 10.000 | True | {} | [資料](formal-67108864-10hz-r3-default-push/controller.json) |
| formal r3 | 64 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](formal-67108864-10hz-r3-datasharing-push/controller.json) |
| loan r1 | 64 MiB | vinc loan | 10 | 9.980 | True | {} | [資料](loan-67108864-10hz-r1-vinc-loan/controller.json) |
| profile r0 | 128 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](profile-134217728-10hz-r0-datasharing-push/controller.json) |
| profile r0 | 128 MiB | shm push | 10 | 4.999 | False | {'rate': 'outside ±5%'} | [資料](profile-134217728-10hz-r0-shm-push/controller.json) |
| pilot r0 | 128 MiB | vinc push | 100 | 40.835 | False | {'missing_receive': 119, 'lost_messages': 119, 'overwrite_events': 29, 'analyzer': 'unqualified'} | [資料](pilot-134217728-100hz-r0-vinc-push/controller.json) |
| pilot r0 | 128 MiB | datasharing push | 100 | 46.012 | False | {'missing_receive': 102, 'analyzer': 'unqualified'} | [資料](pilot-134217728-100hz-r0-datasharing-push/controller.json) |
| pilot r0 | 128 MiB | vinc push | 50 | 41.502 | False | {'missing_receive': 118, 'lost_messages': 118, 'overwrite_events': 28, 'analyzer': 'unqualified'} | [資料](pilot-134217728-50hz-r0-vinc-push/controller.json) |
| pilot r0 | 128 MiB | datasharing push | 50 | 44.716 | False | {'missing_receive': 101, 'analyzer': 'unqualified'} | [資料](pilot-134217728-50hz-r0-datasharing-push/controller.json) |
| pilot r0 | 128 MiB | vinc push | 25 | 25.000 | False | {'missing_receive': 113, 'lost_messages': 113, 'overwrite_events': 44, 'analyzer': 'unqualified'} | [資料](pilot-134217728-25hz-r0-vinc-push/controller.json) |
| pilot r0 | 128 MiB | datasharing push | 25 | 24.999 | False | {'missing_receive': 72, 'analyzer': 'unqualified'} | [資料](pilot-134217728-25hz-r0-datasharing-push/controller.json) |
| pilot r0 | 128 MiB | vinc push | 10 | 10.000 | False | {'missing_receive': 10, 'collisions': 3, 'lost_messages': 10, 'overwrite_events': 10, 'analyzer': 'unqualified'} | [資料](pilot-134217728-10hz-r0-vinc-push/controller.json) |
| pilot r0 | 128 MiB | datasharing push | 10 | 10.000 | True | {} | [資料](pilot-134217728-10hz-r0-datasharing-push/controller.json) |
| pilot r0 | 128 MiB | vinc push | 5 | 5.000 | True | {} | [資料](pilot-134217728-5hz-r0-vinc-push/controller.json) |
| pilot r0 | 128 MiB | datasharing push | 5 | 5.000 | True | {} | [資料](pilot-134217728-5hz-r0-datasharing-push/controller.json) |
| formal r1 | 128 MiB | vinc push | 5 | 5.000 | True | {} | [資料](formal-134217728-5hz-r1-vinc-push/controller.json) |
| formal r1 | 128 MiB | default push | 5 | 5.000 | False | {'missing_receive': 12, 'analyzer': 'unqualified'} | [資料](formal-134217728-5hz-r1-default-push/controller.json) |
| formal r1 | 128 MiB | datasharing push | 5 | 5.000 | True | {} | [資料](formal-134217728-5hz-r1-datasharing-push/controller.json) |
| formal r2 | 128 MiB | datasharing push | 5 | 5.000 | True | {} | [資料](formal-134217728-5hz-r2-datasharing-push/controller.json) |
| formal r2 | 128 MiB | default push | 5 | 5.000 | False | {'missing_receive': 9, 'analyzer': 'unqualified'} | [資料](formal-134217728-5hz-r2-default-push/controller.json) |
| formal r2 | 128 MiB | vinc push | 5 | 5.000 | True | {} | [資料](formal-134217728-5hz-r2-vinc-push/controller.json) |
| formal r3 | 128 MiB | vinc push | 5 | 5.000 | True | {} | [資料](formal-134217728-5hz-r3-vinc-push/controller.json) |
| formal r3 | 128 MiB | default push | 5 | 5.000 | False | {'missing_receive': 15, 'analyzer': 'unqualified'} | [資料](formal-134217728-5hz-r3-default-push/controller.json) |
| formal r3 | 128 MiB | datasharing push | 5 | 5.000 | True | {} | [資料](formal-134217728-5hz-r3-datasharing-push/controller.json) |
| loan r1 | 128 MiB | vinc loan | 5 | 4.980 | True | {} | [資料](loan-134217728-5hz-r1-vinc-loan/controller.json) |

## 證據與重算

- `attempts.json`、`plan.json`、`settings.json`：全部嘗試、凍結設定與記憶體保護門檻。
- 各組 `raw/`、normalized CSV、run.json、metrics.json、resources.json、pacing.csv。
- ROS XML 與運行中的共享映像清單；實際 binary SHA256、CMake 建置資訊及套件版本。
- 以 `python3 -m tools.analyze CASE_DIRECTORY` 重算單組。跨框架比較還會檢查時鐘、所有權、容量、頻率與樣本數一致。
- 本報告只對這份資料集負責；正式失敗不以事後降低頻率或刪除離群值補成成功。
- 測試採記憶體低於 1 GiB 或 swap 增加超過 512 MiB 時中止；這是測試機保護，不是傳輸效能數字。
